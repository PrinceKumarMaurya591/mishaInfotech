package com.mishaInfotech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MishaInfotechApplication {

	public static void main(String[] args) {
		SpringApplication.run(MishaInfotechApplication.class, args);
	}

}
